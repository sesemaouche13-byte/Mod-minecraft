package com.aquapower;

import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemUseAnimation;
import net.minecraft.world.level.Level;

/** Une gourde : on la boit (2 secondes), puis le pouvoir se declenche. Elle n'est pas consommee. */
public class BottleItem extends Item {
    /** Duree de la boisson en ticks (20 ticks = 1 s). */
    static final int DRINK_TICKS = 40;
    /** Recharge apres usage en ticks. */
    static final int COOLDOWN_TICKS = 20 * 20;

    private final Power power;

    public BottleItem(Properties properties, Power power) {
        super(properties);
        this.power = power;
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        player.startUsingItem(hand);
        return InteractionResult.CONSUME;
    }

    @Override
    public ItemUseAnimation getUseAnimation(ItemStack stack) {
        return ItemUseAnimation.DRINK;
    }

    @Override
    public int getUseDuration(ItemStack stack, LivingEntity entity) {
        return DRINK_TICKS;
    }

    /** Animation de "charge" : une double spirale se resserre autour du joueur pendant qu'il boit. */
    @Override
    public void onUseTick(Level level, LivingEntity entity, ItemStack stack, int remaining) {
        if (!(level instanceof ServerLevel sl)) {
            return;
        }
        int used = DRINK_TICKS - remaining;
        double radius = Math.max(0.2, 1.3 - used * 0.028);
        for (int arm = 0; arm < 2; arm++) {
            double a = used * 0.55 + arm * Math.PI;
            PowerEffects.parts(sl, power.charge,
                    entity.getX() + Math.cos(a) * radius,
                    entity.getY() + 0.1 + used * 0.045,
                    entity.getZ() + Math.sin(a) * radius,
                    1, 0, 0, 0, 0);
        }
        if (used % 6 == 0) {
            PowerEffects.sound(sl, entity.getX(), entity.getY(), entity.getZ(),
                    SoundEvents.AMETHYST_BLOCK_CHIME, 0.7f, 0.5f + used * 0.03f);
        }
    }

    @Override
    public ItemStack finishUsingItem(ItemStack stack, Level level, LivingEntity entity) {
        if (level instanceof ServerLevel sl && entity instanceof ServerPlayer player) {
            PowerEffects.apply(power, sl, player);
            ServerPlayNetworking.send(player, new FxPayload(power.ordinal()));
            player.getCooldowns().addCooldown(stack, COOLDOWN_TICKS);
        }
        return stack;
    }
}
