package com.aquapower;

import net.minecraft.core.Holder;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.List;
import java.util.Random;

/** Tout ce qui se passe dans le monde quand une gourde est bue : mouvement, effets, degats, particules, sons. */
public final class PowerEffects {
    private static final Random RNG = new Random();

    private PowerEffects() {
    }

    // ------------------------------------------------------------ helpers
    static void sound(ServerLevel l, double x, double y, double z, SoundEvent e, float vol, float pitch) {
        l.playSound((Player) null, x, y, z, e, SoundSource.PLAYERS, vol, pitch);
    }

    static void parts(ServerLevel l, ParticleOptions o, double x, double y, double z,
                      int n, double dx, double dy, double dz, double speed) {
        l.sendParticles(o, x, y, z, n, dx, dy, dz, speed);
    }

    static void ring(ServerLevel l, ParticleOptions o, double cx, double cy, double cz, double r, int n) {
        for (int k = 0; k < n; k++) {
            double a = Math.PI * 2 * k / n;
            l.sendParticles(o, cx + Math.cos(a) * r, cy, cz + Math.sin(a) * r, 1, 0, 0, 0, 0);
        }
    }

    /** Onde de choc : des anneaux de particules qui s'agrandissent a chaque tick. */
    static void shockwave(ServerLevel l, ServerPlayer p, ParticleOptions o, int ticks, double perTick) {
        double cx = p.getX();
        double cy = p.getY() + 0.15;
        double cz = p.getZ();
        for (int i = 1; i <= ticks; i++) {
            final int t = i;
            Scheduler.later(i - 1, () -> ring(l, o, cx, cy, cz, t * perTick, 12 + t * 4));
        }
    }

    /** Double helice qui monte autour du joueur. */
    static void helix(ServerLevel l, ServerPlayer p, ParticleOptions o, int ticks, double radius) {
        for (int i = 0; i < ticks; i++) {
            final int t = i;
            Scheduler.later(i, () -> {
                for (int arm = 0; arm < 2; arm++) {
                    double a = t * 0.55 + arm * Math.PI;
                    double y = p.getY() + (t * 0.12) % 2.2;
                    l.sendParticles(o, p.getX() + Math.cos(a) * radius, y + 0.1,
                            p.getZ() + Math.sin(a) * radius, 1, 0, 0, 0, 0);
                }
            });
        }
    }

    static List<LivingEntity> near(ServerLevel l, ServerPlayer p, double r) {
        return l.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(r),
                e -> e != p && e.isAlive());
    }

    static void effect(LivingEntity e, Holder<MobEffect> effect, int ticks, int amplifier) {
        e.addEffect(new MobEffectInstance(effect, ticks, amplifier));
    }

    // ------------------------------------------------------------ dispatch
    public static void apply(Power power, ServerLevel l, ServerPlayer p) {
        switch (power) {
            case TORNADO -> tornado(l, p);
            case GLACIER -> glacier(l, p);
            case THUNDER -> thunder(l, p);
            case SPRING -> spring(l, p);
            case TSUNAMI -> tsunami(l, p);
        }
    }

    // ------------------------------------------------------------ TORNADE
    private static void tornado(ServerLevel l, ServerPlayer p) {
        sound(l, p.getX(), p.getY(), p.getZ(), SoundEvents.FIREWORK_ROCKET_LAUNCH, 1.2f, 0.6f);
        sound(l, p.getX(), p.getY(), p.getZ(), SoundEvents.ENDER_DRAGON_FLAP, 1.5f, 0.8f);

        // dash dans la direction du regard
        Vec3 look = p.getLookAngle();
        p.setDeltaMovement(look.scale(2.4).add(0, 0.4, 0));
        p.hurtMarked = true;
        effect(p, MobEffects.SPEED, 200, 2);
        effect(p, MobEffects.SLOW_FALLING, 160, 0);

        // les monstres proches sont aspires vers le haut
        for (LivingEntity e : near(l, p, 6)) {
            e.setDeltaMovement(e.getDeltaMovement().add(0, 1.0, 0));
            e.hurtMarked = true;
        }

        shockwave(l, p, ParticleTypes.CLOUD, 10, 0.7);
        helix(l, p, ParticleTypes.CLOUD, 20, 1.0);
        // traînee derriere le joueur
        for (int i = 0; i < 24; i++) {
            Scheduler.later(i, () -> {
                parts(l, ParticleTypes.CLOUD, p.getX(), p.getY() + 0.8, p.getZ(), 8, 0.3, 0.3, 0.3, 0.05);
                parts(l, ParticleTypes.POOF, p.getX(), p.getY() + 0.5, p.getZ(), 4, 0.2, 0.2, 0.2, 0.1);
            });
        }
    }

    // ------------------------------------------------------------ GLACIER
    private static void glacier(ServerLevel l, ServerPlayer p) {
        sound(l, p.getX(), p.getY(), p.getZ(), SoundEvents.GLASS_BREAK, 1.5f, 0.6f);
        sound(l, p.getX(), p.getY(), p.getZ(), SoundEvents.AMETHYST_BLOCK_CHIME, 1.5f, 0.5f);

        effect(p, MobEffects.RESISTANCE, 200, 1);
        for (LivingEntity e : near(l, p, 10)) {
            effect(e, MobEffects.SLOWNESS, 200, 4);
            e.setTicksFrozen(300);
            e.hurtServer(l, l.damageSources().freeze(), 3f);
            parts(l, ParticleTypes.SNOWFLAKE, e.getX(), e.getY() + 1, e.getZ(), 25, 0.4, 0.6, 0.4, 0.05);
        }

        shockwave(l, p, ParticleTypes.SNOWFLAKE, 14, 0.75);
        helix(l, p, ParticleTypes.SNOWFLAKE, 30, 1.1);
        parts(l, ParticleTypes.CLOUD, p.getX(), p.getY() + 0.3, p.getZ(), 60, 2.5, 0.2, 2.5, 0.02);
        parts(l, ParticleTypes.SNOWFLAKE, p.getX(), p.getY() + 1, p.getZ(), 80, 3, 1.5, 3, 0.05);
    }

    // ------------------------------------------------------------ FOUDRE
    private static void thunder(ServerLevel l, ServerPlayer p) {
        sound(l, p.getX(), p.getY(), p.getZ(), SoundEvents.TRIDENT_THUNDER, 2f, 1f);

        effect(p, MobEffects.SPEED, 300, 1);
        effect(p, MobEffects.STRENGTH, 300, 1);

        helix(l, p, ParticleTypes.ELECTRIC_SPARK, 30, 0.9);
        parts(l, ParticleTypes.ELECTRIC_SPARK, p.getX(), p.getY() + 1, p.getZ(), 120, 1.2, 1.2, 1.2, 0.4);

        // 6 eclairs, un tous les 4 ticks, autour du joueur
        for (int i = 0; i < 6; i++) {
            Scheduler.later(i * 4, () -> {
                double ang = RNG.nextDouble() * Math.PI * 2;
                double dist = 3 + RNG.nextDouble() * 5;
                strike(l, p, p.getX() + Math.cos(ang) * dist, p.getY(), p.getZ() + Math.sin(ang) * dist);
            });
        }
    }

    private static void strike(ServerLevel l, ServerPlayer p, double x, double y, double z) {
        LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(l, EntitySpawnReason.TRIGGERED);
        if (bolt != null) {
            bolt.setPos(x, y, z);
            bolt.setVisualOnly(true); // pas de feu, pas de degats au joueur
            l.addFreshEntity(bolt);
        }
        AABB box = new AABB(x - 3, y - 2, z - 3, x + 3, y + 4, z + 3);
        for (LivingEntity e : l.getEntitiesOfClass(LivingEntity.class, box, ent -> ent != p && ent.isAlive())) {
            e.hurtServer(l, l.damageSources().lightningBolt(), 10f);
        }
        parts(l, ParticleTypes.ELECTRIC_SPARK, x, y + 1, z, 40, 0.8, 1.2, 0.8, 0.3);
    }

    // ------------------------------------------------------------ SOURCE
    private static void spring(ServerLevel l, ServerPlayer p) {
        sound(l, p.getX(), p.getY(), p.getZ(), SoundEvents.PLAYER_LEVELUP, 1.2f, 1f);
        sound(l, p.getX(), p.getY(), p.getZ(), SoundEvents.BEACON_ACTIVATE, 1.2f, 1.2f);

        p.heal(12f);
        effect(p, MobEffects.REGENERATION, 200, 2);
        effect(p, MobEffects.ABSORPTION, 600, 2);

        helix(l, p, ParticleTypes.END_ROD, 40, 0.9);
        shockwave(l, p, ParticleTypes.HAPPY_VILLAGER, 10, 0.5);
        parts(l, ParticleTypes.HEART, p.getX(), p.getY() + 1.5, p.getZ(), 15, 0.6, 0.5, 0.6, 0.1);
        parts(l, ParticleTypes.TOTEM_OF_UNDYING, p.getX(), p.getY() + 1, p.getZ(), 50, 0.5, 1, 0.5, 0.4);
    }

    // ------------------------------------------------------------ TSUNAMI
    private static void tsunami(ServerLevel l, ServerPlayer p) {
        sound(l, p.getX(), p.getY(), p.getZ(), SoundEvents.PLAYER_SPLASH_HIGH_SPEED, 1.5f, 0.7f);
        sound(l, p.getX(), p.getY(), p.getZ(), SoundEvents.TRIDENT_RIPTIDE_3, 1.5f, 0.8f);

        effect(p, MobEffects.DOLPHINS_GRACE, 600, 0);
        effect(p, MobEffects.WATER_BREATHING, 600, 0);

        // la vague repousse tout ce qui est a moins de 10 blocs
        for (LivingEntity e : near(l, p, 10)) {
            Vec3 dir = e.position().subtract(p.position());
            if (dir.length() > 0.01) {
                dir = dir.normalize();
            }
            e.setDeltaMovement(dir.x * 1.8, 0.6, dir.z * 1.8);
            e.hurtMarked = true;
            e.hurtServer(l, l.damageSources().magic(), 4f);
        }

        shockwave(l, p, ParticleTypes.SPLASH, 14, 0.75);
        shockwave(l, p, ParticleTypes.BUBBLE_POP, 14, 0.7);
        parts(l, ParticleTypes.SPLASH, p.getX(), p.getY() + 1, p.getZ(), 150, 3, 2, 3, 0.3);
        parts(l, ParticleTypes.FALLING_WATER, p.getX(), p.getY() + 3, p.getZ(), 80, 3, 1, 3, 0.0);
    }
}
