package com.aquapower;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;

import java.util.EnumMap;
import java.util.Map;

public class AquaPower implements ModInitializer {
    public static final String MOD_ID = "aquapower";
    public static final Map<Power, Item> ITEMS = new EnumMap<>(Power.class);

    @Override
    public void onInitialize() {
        for (Power power : Power.values()) {
            Identifier id = Identifier.fromNamespaceAndPath(MOD_ID, power.itemId);
            ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, id);
            Item item = new BottleItem(new Item.Properties().setId(key).stacksTo(1), power);
            Registry.register(BuiltInRegistries.ITEM, key, item);
            ITEMS.put(power, item);
        }

        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.TOOLS_AND_UTILITIES)
                .register(entries -> ITEMS.values().forEach(entries::accept));

        PayloadTypeRegistry.playS2C().register(FxPayload.TYPE, FxPayload.CODEC);
        Scheduler.init();
    }
}
