package com.aquapower;

import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;

/** Les 5 gourdes et leur identite visuelle. */
public enum Power {
    TORNADO("bottle_tornado", "TORNADE", 0x9FD8E8, ParticleTypes.CLOUD),
    GLACIER("bottle_glacier", "GLACIER", 0x69B7F5, ParticleTypes.SNOWFLAKE),
    THUNDER("bottle_thunder", "FOUDRE", 0xF2C230, ParticleTypes.ELECTRIC_SPARK),
    SPRING("bottle_spring", "SOURCE", 0x3FD07A, ParticleTypes.HAPPY_VILLAGER),
    TSUNAMI("bottle_tsunami", "TSUNAMI", 0x2F6BE8, ParticleTypes.SPLASH);

    public final String itemId;
    public final String title;
    public final int color;
    /** Particule de "charge" pendant que le joueur boit. */
    public final ParticleOptions charge;

    Power(String itemId, String title, int color, ParticleOptions charge) {
        this.itemId = itemId;
        this.title = title;
        this.color = color;
        this.charge = charge;
    }
}
