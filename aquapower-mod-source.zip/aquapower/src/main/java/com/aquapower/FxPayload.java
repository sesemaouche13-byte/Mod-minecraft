package com.aquapower;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

/** Serveur -> client : "lance l'animation d'ecran du pouvoir n". */
public record FxPayload(int power) implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<FxPayload> TYPE =
            new CustomPacketPayload.Type<>(Identifier.fromNamespaceAndPath(AquaPower.MOD_ID, "fx"));

    public static final StreamCodec<RegistryFriendlyByteBuf, FxPayload> CODEC =
            StreamCodec.composite(ByteBufCodecs.VAR_INT, FxPayload::power, FxPayload::new);

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
