package com.aquapower;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.Identifier;
import org.joml.Matrix3x2fStack;

import java.util.Random;

/** Animation plein ecran qui accompagne chaque pouvoir. */
public class AquaPowerClient implements ClientModInitializer {
    static final long DURATION = 3600;

    static Power current;
    static long start;

    @Override
    public void onInitializeClient() {
        ClientPlayNetworking.registerGlobalReceiver(FxPayload.TYPE, (payload, context) -> {
            Power[] all = Power.values();
            if (payload.power() >= 0 && payload.power() < all.length) {
                current = all[payload.power()];
                start = System.currentTimeMillis();
            }
        });

        HudElementRegistry.addLast(
                Identifier.fromNamespaceAndPath(AquaPower.MOD_ID, "fx"),
                (graphics, deltaTracker) -> render(graphics));
    }

    static void render(GuiGraphics g) {
        Power power = current;
        if (power == null) {
            return;
        }
        long now = System.currentTimeMillis();
        float t = (now - start) / (float) DURATION;
        if (t >= 1f) {
            current = null;
            return;
        }
        int w = g.guiWidth();
        int h = g.guiHeight();
        float e = env(t);

        // flash d'ouverture (un seul, qui s'estompe vite)
        if (t < 0.12f) {
            g.fill(0, 0, w, h, alpha(0xFFFFFF, (1f - t / 0.12f) * 0.7f));
        }

        switch (power) {
            case TORNADO -> tornado(g, w, h, now, e);
            case GLACIER -> glacier(g, w, h, now, e);
            case THUNDER -> thunder(g, w, h, now, e);
            case SPRING -> spring(g, w, h, now, e);
            case TSUNAMI -> tsunami(g, w, h, t, now);
        }

        // titre qui "pop" puis s'efface
        float k = Math.min(1f, t / 0.1f);
        float scale = 5f * (k + 0.2f * (float) Math.sin(k * Math.PI));
        float a = t > 0.75f ? (1f - t) / 0.25f : 1f;
        bigText(g, power.title, w / 2f, h * 0.2f, scale, power.color, a);
    }

    // ------------------------------------------------------------ effets par pouvoir
    static void tornado(GuiGraphics g, int w, int h, long ms, float e) {
        g.fill(0, 0, w, h, alpha(0xBFEFFF, 0.12f * e));
        for (int i = 0; i < 45; i++) {
            Random r = new Random(i * 131L + 7);
            int y = r.nextInt(Math.max(1, h));
            int len = 60 + r.nextInt(180);
            float speed = 0.6f + r.nextFloat() * 1.2f;
            int x = (int) (((ms * speed) + r.nextInt(Math.max(1, w))) % (w + len)) - len;
            g.fill(x, y, x + len, y + 1 + (i % 2), alpha(0xFFFFFF, 0.55f * e));
        }
        edges(g, w, h, 0xFFFFFF, 0.35f * e, 10, Math.max(3, w / 120));
    }

    static void glacier(GuiGraphics g, int w, int h, long ms, float e) {
        g.fill(0, 0, w, h, alpha(0x66CCFF, 0.2f * e));
        edges(g, w, h, 0xE8F8FF, 0.7f * e, 20, Math.max(4, w / 90));
        float sec = ms / 1000f;
        for (int i = 0; i < 80; i++) {
            Random r = new Random(i * 977L + 3);
            int x0 = r.nextInt(Math.max(1, w));
            float speed = h * (0.15f + r.nextFloat() * 0.2f);
            int y = (int) ((sec * speed + r.nextInt(Math.max(1, h))) % h);
            int x = x0 + (int) (Math.sin(sec * 2 + i) * 12);
            int s = 2 + r.nextInt(3);
            g.fill(x, y, x + s, y + s, alpha(0xFFFFFF, 0.9f * e));
        }
    }

    /** Eclairs : un flash doux et un zigzag, environ 3 fois par seconde au maximum. */
    static void thunder(GuiGraphics g, int w, int h, long ms, float e) {
        long slot = ms / 350;
        Random r = new Random(slot * 31L);
        float phase = (ms % 350) / 350f;
        if (phase < 0.4f) {
            float k = 1f - phase / 0.4f;
            g.fill(0, 0, w, h, alpha(0xFFF2A0, 0.22f * k * e));
            for (int b = 0; b < 2; b++) {
                int x = r.nextInt(Math.max(1, w));
                for (int y = 0; y < h; y += 18) {
                    int nx = x + r.nextInt(31) - 15;
                    int x1 = Math.min(x, nx);
                    int x2 = Math.max(x, nx) + 3;
                    g.fill(x1, y, x2, y + 18, alpha(0xFFFFFF, 0.9f * k * e));
                    g.fill(x1 - 2, y, x2 + 2, y + 18, alpha(0xFFE040, 0.25f * k * e));
                    x = nx;
                }
            }
        }
        edges(g, w, h, 0xFFD020, 0.35f * e, 10, Math.max(3, w / 120));
    }

    static void spring(GuiGraphics g, int w, int h, long ms, float e) {
        g.fill(0, 0, w, h, alpha(0x40FF90, 0.1f * e));
        edges(g, w, h, 0x7CFFB0, 0.6f * e, 16, Math.max(4, w / 100));
        float sec = ms / 1000f;
        for (int i = 0; i < 70; i++) {
            Random r = new Random(i * 613L + 11);
            int x = r.nextInt(Math.max(1, w)) + (int) (Math.sin(sec * 2 + i) * 10);
            float speed = h * 0.25f + r.nextInt(Math.max(1, h / 4));
            int y = h - (int) ((sec * speed + r.nextInt(Math.max(1, h))) % h);
            int s = 2 + r.nextInt(3);
            int col = r.nextBoolean() ? 0xFFE97A : 0x9CFFC4;
            g.fill(x, y, x + s, y + s, alpha(col, 0.9f * e));
        }
    }

    /** Une vague d'eau qui monte puis redescend, avec bulles. */
    static void tsunami(GuiGraphics g, int w, int h, float t, long ms) {
        float level = h * 0.6f * (float) Math.sin(Math.PI * t);
        for (int x = 0; x < w; x += 4) {
            int top = (int) (h - level + Math.sin(x * 0.035 + ms / 160.0) * 10);
            if (top >= h) {
                continue;
            }
            g.fill(x, top, x + 4, h, alpha(0x2F6BE8, 0.45f));
            g.fill(x, top, x + 4, top + 3, alpha(0xE0F0FF, 0.8f));
        }
        float sec = ms / 1000f;
        for (int i = 0; i < 40; i++) {
            Random r = new Random(i * 389L + 5);
            int x = r.nextInt(Math.max(1, w));
            int y = h - (int) ((sec * 80 + r.nextInt(Math.max(1, h))) % h);
            if (y > h - level) {
                int s = 3 + r.nextInt(4);
                g.renderOutline(x, y, s, s, alpha(0xFFFFFF, 0.8f));
            }
        }
    }

    // ------------------------------------------------------------ helpers
    static int alpha(int rgb, float a) {
        int ai = Math.max(0, Math.min(255, (int) (a * 255f)));
        return (ai << 24) | (rgb & 0xFFFFFF);
    }

    static float env(float t) {
        return Math.min(1f, Math.min(t, 1f - t) * 8f);
    }

    static void bigText(GuiGraphics g, String text, float cx, float cy, float scale, int rgb, float a) {
        if (a < 0.05f) {
            return;
        }
        Font font = Minecraft.getInstance().font;
        Matrix3x2fStack m = g.pose();
        m.pushMatrix();
        m.translate(cx, cy);
        m.scale(scale, scale);
        int tw = font.width(text);
        g.drawString(font, text, -tw / 2, -font.lineHeight / 2, alpha(rgb, a), true);
        m.popMatrix();
    }

    static void edges(GuiGraphics g, int w, int h, int rgb, float strength, int steps, int size) {
        for (int i = 0; i < steps; i++) {
            float k = 1f - i / (float) steps;
            int c = alpha(rgb, k * k * strength);
            g.fill(i * size, 0, (i + 1) * size, h, c);
            g.fill(w - (i + 1) * size, 0, w - i * size, h, c);
            g.fill(0, i * size, w, (i + 1) * size, c);
            g.fill(0, h - (i + 1) * size, w, h - i * size, c);
        }
    }
}
