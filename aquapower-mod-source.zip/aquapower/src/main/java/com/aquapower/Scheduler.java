package com.aquapower;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/** Petit planificateur : execute du code N ticks plus tard (les animations de particules). */
public final class Scheduler {
    private static final class Task {
        int delay;
        final Runnable run;

        Task(int delay, Runnable run) {
            this.delay = delay;
            this.run = run;
        }
    }

    private static final List<Task> TASKS = new ArrayList<>();

    private Scheduler() {
    }

    public static void later(int ticks, Runnable run) {
        TASKS.add(new Task(Math.max(0, ticks), run));
    }

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (TASKS.isEmpty()) {
                return;
            }
            List<Runnable> due = new ArrayList<>();
            for (Iterator<Task> it = TASKS.iterator(); it.hasNext(); ) {
                Task t = it.next();
                if (t.delay-- <= 0) {
                    due.add(t.run);
                    it.remove();
                }
            }
            for (Runnable r : due) {
                try {
                    r.run();
                } catch (Exception ignored) {
                    // une animation ratee ne doit jamais faire planter le serveur
                }
            }
        });
    }
}
